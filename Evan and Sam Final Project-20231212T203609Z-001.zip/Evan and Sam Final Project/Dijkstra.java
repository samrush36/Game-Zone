import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

public class Dijkstra {
    private final int[][] board;
    private final int rows;
    private final int cols;
    private final int START = 3;
    private final int END = 4;
    private final int EMPTY = 0;
    private final int OBSTACLE = -1;

    public Dijkstra(int[][] board) {
        this.board = board;
        this.rows = board.length;
        this.cols = board[0].length;
    }

    public List<int[]> findShortestPath() {
        PriorityQueue<Node> minHeap = new PriorityQueue<>();
        int[][] distances = new int[rows][cols];
        boolean[][] visited = new boolean[rows][cols];
        List<int[]> path = new ArrayList<>();

        for (int i = 0; i < rows; i++) {
            Arrays.fill(distances[i], Integer.MAX_VALUE);
        }

        int[] start = findCell(START);
        distances[start[0]][start[1]] = 0;
        minHeap.offer(new Node(start[0], start[1], 0));

        while (!minHeap.isEmpty()) {
            Node current = minHeap.poll();

            if (visited[current.row][current.col]) {
                continue;
            }

            visited[current.row][current.col] = true;

            if (board[current.row][current.col] == END) {
                // Found the end, reconstruct the path
                path.add(new int[]{current.row, current.col});
                while (current.parent != null) {
                    current = current.parent;
                    path.add(new int[]{current.row, current.col});
                }
                return path;
            }

            updateNeighbors(current, minHeap, distances);
        }

        return path; // No path found
    }

    private void updateNeighbors(Node current, PriorityQueue<Node> minHeap, int[][] distances) {
        int[] dr = {-1, 1, 0, 0}; // Directions: up, down, left, right
        int[] dc = {0, 0, -1, 1};

        for (int i = 0; i < 4; i++) {
            int newRow = current.row + dr[i];
            int newCol = current.col + dc[i];

            if (isValid(newRow, newCol) && !visited[newRow][newCol] && board[newRow][newCol] != OBSTACLE) {
                int newDistance = distances[current.row][current.col] + 1;

                if (newDistance < distances[newRow][newCol]) {
                    distances[newRow][newCol] = newDistance;
                    minHeap.offer(new Node(newRow, newCol, newDistance, current));
                }
            }
        }
    }

    private boolean isValid(int row, int col) {
        return row >= 0 && row < rows && col >= 0 && col < cols;
    }

    private int[] findCell(int cellType) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (board[i][j] == cellType) {
                    return new int[]{i, j};
                }
            }
        }
        return null;
    }

    private static class Node implements Comparable<Node> {
        int row, col, distance;
        Node parent;

        public Node(int row, int col, int distance) {
            this.row = row;
            this.col = col;
            this.distance = distance;
            this.parent = null;
        }

        public Node(int row, int col, int distance, Node parent) {
            this.row = row;
            this.col = col;
            this.distance = distance;
            this.parent = parent;
        }

        @Override
        public int compareTo(Node other) {
            return Integer.compare(this.distance, other.distance);
        }
    }
}
