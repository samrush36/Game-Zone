import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class BoardPanel extends JPanel {
    private final Board board;

    // Color mapping for different board values
    private static final Map<Integer, Color> colorMap = new HashMap<>();

    static {
        colorMap.put(0, Color.WHITE);     // EMPTY
        colorMap.put(-1, Color.BLACK);    // OBSTACLE
        colorMap.put(1, Color.YELLOW);    // KNOWN
        colorMap.put(2, Color.BLUE);      // PATH
        colorMap.put(3, Color.GREEN);     // START
        colorMap.put(4, Color.RED);       // END
    }

    public BoardPanel(Board board) {
        this.board = board;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int[][] boardArray = board.getBoard();

        int cellSize = Math.min(getWidth() / boardArray[0].length, getHeight() / boardArray.length);

        for (int i = 0; i < boardArray.length; i++) {
            for (int j = 0; j < boardArray[0].length; j++) {
                int cellValue = boardArray[i][j];
                g.setColor(colorMap.get(cellValue));
                g.fillRect(j * cellSize, i * cellSize, cellSize, cellSize);
                g.setColor(Color.BLACK);
                g.drawRect(j * cellSize, i * cellSize, cellSize, cellSize);
            }
        }
    }
}
