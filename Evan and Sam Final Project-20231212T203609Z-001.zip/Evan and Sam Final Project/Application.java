import javax.swing.*;
import java.awt.*;

public class Application {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Board Display");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            Board board = new Board();
            BoardPanel boardPanel = new BoardPanel(board);

            frame.getContentPane().add(boardPanel);

            frame.pack(); // Pack the frame to set the size based on the components
            frame.setLocationRelativeTo(null); // Center the frame on the screen
            frame.setVisible(true);
        });
    }
}
