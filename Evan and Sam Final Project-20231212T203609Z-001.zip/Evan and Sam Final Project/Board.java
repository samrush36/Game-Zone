import java.util.Random;

public class Board {
    public int[][] board;

    public final int EMPTY = 0;
    public final int OBSTACLE = -1;
    public final int KNOWN = 1;
    public final int PATH = 2;
    public final int START = 3;
    public final int END = 4;

    public Board() {
        board = new int[50][50];
        createBoard();
    }

    public void createBoard() {
        resetBoard();
        addObstacles(50);
        addStartEndPoints();
    }

    public void resetBoard() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                board[i][j] = EMPTY;
            }
        }
    }

    public void addObstacles(int numObstacles) {
        for (int i = 0; i < numObstacles; i++) {
            int[] point = getRandomPoint();
            board[point[0]][point[1]] = OBSTACLE;
        }
    }

    public void addStartEndPoints() {
        int[] point1 = getRandomPoint();
        int[] point2 = getRandomPoint();

        while (point1[0] == point2[0] && point1[1] == point2[1]) {
            // Ensure the points are distinct
            point2 = getRandomPoint();
        }

        board[point1[0]][point1[1]] = START;
        board[point2[0]][point2[1]] = END;
    }

    private int[] getRandomPoint() {
        Random random = new Random();
        int x = random.nextInt(50);
        int y = random.nextInt(50);
        return new int[] { x, y };
    }

    public List<int[]> findShortestPath() {
        Dijkstra dijkstra = new Dijkstra(board);
        return dijkstra.findShortestPath();
    }

    public int[][] getBoard() {
        return board;
    }
}
