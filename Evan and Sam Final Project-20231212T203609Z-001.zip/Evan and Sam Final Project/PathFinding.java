public class PathFinding {

    public static AStar() {

    }

    public static 
}